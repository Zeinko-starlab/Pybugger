from rich.console import Console
from rich.progress import track
from rich.text import Text
import traceback
import datetime
import time

class Debugger:
    def __init__(self):
        self.log_file = "debug_log.txt"
        self.console = Console()

    def debug(self, file_name, log=True, processing_delay=0.01):
        try:
            self.console.print(Text(f"Starting debugging for: {file_name}", style="bold cyan"))
            
            # Simulate a loading bar
            for _ in track(range(100), description="Processing..."):
                time.sleep(processing_delay)

            with open(file_name, "r") as file:
                content = file.read()

            # Attempt to execute the file content
            try:
                exec(content)
                self.console.print(Text(f"[DEBUG] {file_name} executed successfully.", style="bold green"))

                # Log success
                if log:
                    with open(self.log_file, "a") as log_file:
                        log_file.write(f"[DEBUG] {file_name} executed successfully at {datetime.datetime.now()}.\n")
                    self.console.print(Text("Execution success logged to debug_log.txt", style="bold green"))

            except Exception as execution_error:
                # Capture error details
                error_message = traceback.format_exc()
                error_line = self._extract_error_line(error_message)

                # Display error details
                self.console.print(Text(f"An error occurred during execution:\n{error_message}", style="bold red"))
                if error_line:
                    self.console.print(Text(f"Error detected at: {error_line}", style="bold yellow"))

                # Log the error if logging is enabled
                if log:
                    with open(self.log_file, "a") as log_file:
                        log_file.write(f"[ERROR] {file_name} - {datetime.datetime.now()}\n")
                        log_file.write(f"Error Line: {error_line}\n" if error_line else "")
                        log_file.write(error_message + "\n")
                    self.console.print(Text("Error details logged to debug_log.txt", style="bold red"))

            # Log or display the file content
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            header = f"\n[CODE] {file_name} - {timestamp}\n" + ("=" * 40) + "\n"

            if log:
                with open(self.log_file, "a") as log_file:
                    log_file.write(header)
                    log_file.write(content + "\n")
                self.console.print(Text("File content logged to debug_log.txt", style="bold green"))
            else:
                self.console.print(Text(header, style="bold yellow"))
                self.console.print(Text(content, style="bold red"))

        except Exception as e:
            # Handle unexpected file-reading or other errors
            error_message = traceback.format_exc()
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            header = f"\n[ERROR] {file_name} - {timestamp}\n" + ("=" * 40) + "\n"

            self.console.print(Text(f"An unexpected error occurred:\n{error_message}", style="bold red"))

            if log:
                with open(self.log_file, "a") as log_file:
                    log_file.write(header)
                    log_file.write(error_message + "\n")
                self.console.print(Text("Unexpected error details logged to debug_log.txt", style="bold red"))

    def _extract_error_line(self, error_message):
        """Extracts the line number where an error occurred from a traceback message."""
        lines = error_message.splitlines()
        for line in lines:
            if "File" in line and ", line " in line:
                return line.strip()
        return None